<?php 

	function shuffle_arrays_simultaneously($array1, $array2) {
		$combined = array_combine($array1, $array2);

    	
    	$keys = array_keys($combined);

    	
    	shuffle($keys);

    	
    	$shuffled_array1 = [];
    	$shuffled_array2 = [];

    	foreach ($keys as $key) {
        	$shuffled_array1[] = $key;
        	$shuffled_array2[] = $combined[$key];
    	}

    	return [$shuffled_array1, $shuffled_array2];
	}

?>