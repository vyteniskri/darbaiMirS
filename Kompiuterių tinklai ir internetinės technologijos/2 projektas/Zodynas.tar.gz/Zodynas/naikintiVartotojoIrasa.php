<?php
	session_start(); 
include("include/nustatymai.php");
include("include/functions.php");

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

$userid = $_SESSION['userid'];

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
$sql = "SELECT * FROM " . TBL_VARTOTOJU_WORDS . " WHERE user_id='$userid'";
$result = mysqli_query($db, $sql);

while($row = mysqli_fetch_assoc($result)) { 
	$naikinti=(isset($_POST['naikinti_'.$row['zodis']]));
	if ($naikinti){
		$keisti[]=$row['zodis']; 	
	}
}
$_SESSION['ka_keisti']=$keisti; 

header("Location:naikintiVartotojoIrasadb.php");exit;
?>