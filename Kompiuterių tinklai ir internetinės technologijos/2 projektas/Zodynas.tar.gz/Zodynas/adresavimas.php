<?php
session_start();

$prevPage = $_SERVER['HTTP_REFERER'];
if (strpos($prevPage, 'kalbuZodynai.php') !== false) { //<--- ateinama is meniu

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    	$pasirinktaKalba = $_POST['kalba'];
    	$_SESSION['kalba'] = $pasirinktaKalba;

		header("Location:kalbosPuslapis.php");
    	exit();
	}
}

if (strpos($prevPage, 'kalbosPuslapis.php') !== false) { //<--- ateinama is kalbos pasirinkimo puslapio 
	
	$pasirinktasLygis = $_POST['lygis'];
	$_SESSION['lygis'] = $pasirinktasLygis;
	
	header("Location:lygioPuslapis.php");
    exit();
}

if (strpos($prevPage, 'lygioPuslapis.php') !== false) { //<--- ateinama is lygio pasirinkimo puslapio 
	
	$pasirinktaTematika = $_POST['tematika'];
	$_SESSION['tematika'] = $pasirinktaTematika;
	
	header("Location:priskirtiKLT.php"); // <--- Priskiriamos zodziu reiksmes - uzsienio ir lietuvisku
    exit();
}

?>