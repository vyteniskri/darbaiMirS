<?php
session_start();

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

include("include/nustatymai.php");

$incorrectWords = $_POST['incorrectWords'];
$busenos = $_POST['busenos'];
//Zinutei

$_SESSION['zodziai_issaugoti_succses'] =  "<font size=\"20\" color=\"#00ff00\">* Progresas sėkmingai išsaugotas</font>";

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
$username = $_SESSION['user'];
$userid = $_SESSION['userid'];
$email = $_SESSION['umail'];

$kalba = $_SESSION['kalba'];
$level = $_SESSION['lygis'];
$tematika = $_SESSION['tematika'];
$_SESSION['currentIndex'] = 0;

foreach ($incorrectWords as $word) {
	$currentIndex = $_SESSION['currentIndex'] ?? 0;
	$busena = $busenos[$currentIndex];
	$result = true;

		 $checkQuery = "SELECT COUNT(*) FROM ". TBL_WRONG_WORDS2 ." WHERE user_id='$userid' 
			AND zodis='$word'"; 
		$result = mysqli_query($db, $checkQuery); 

	if ($result) {
        $row = mysqli_fetch_array($result);
        $count = $row[0];
		if ($count == 0 && $busena == "neatsakyta") {
			$insertQuery = "INSERT INTO ". TBL_WRONG_WORDS2 ." (user_id, zodis, kiekis, busena)
			VALUES ('$userid', '$word', 1, 'neatsakyta')";
			mysqli_query($db, $insertQuery);

		} else {
			if ($busena == "neatsakyta"){
				$updateQuery = "UPDATE ". TBL_WRONG_WORDS2 ." SET kiekis = kiekis + 1, busena = 'neatsakyta'  WHERE user_id='$userid' 
					AND zodis='$word'";
				mysqli_query($db, $updateQuery);
			} else {
				$updateQuery = "UPDATE ". TBL_WRONG_WORDS2 ." SET busena = 'atsakyta' WHERE user_id='$userid' 
					AND zodis='$word'";
            	mysqli_query($db, $updateQuery);
			}

		}
		
	} else {
		echo "Error in check query: " . mysqli_error($db);
	}
	$_SESSION['currentIndex'] = $currentIndex + 1;
    
}


$prevPage = $_SERVER['HTTP_REFERER'];
if (strpos($prevPage, 'mokymosi_puslapis.php') !== false) {
	header("Location:priskirtiKLT.php");
}

?>
