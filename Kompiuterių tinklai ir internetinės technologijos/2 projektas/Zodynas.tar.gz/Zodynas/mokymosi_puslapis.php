<?php
include("index.php");
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}


include("shuffleWords.php");

$wordsArray = $_SESSION['wordsArray1'];
$correctWordsArray = $_SESSION['correctWordsArray1'];
$userid = $_SESSION['userid'];

//Iteruojame per zodzius
if (!empty($wordsArray) && !empty($correctWordsArray)) {
    $currentIndex = $_SESSION['currentIndex'] ?? 0;

	if ($currentIndex == 0){
		echo $_SESSION['zodziai_issaugoti_succses'];
		$_SESSION['zodziai_issaugoti_succses'] = "";
	}
    if ($currentIndex < count($wordsArray)) {
        $currentWord = $wordsArray[$currentIndex];
		$currentCorrectWord = $correctWordsArray[$currentIndex];
		$_SESSION['currentIndex'] = $currentIndex + 1;
		$_SESSION['currentCorrectWord'] = $currentCorrectWord;
		$_SESSION['wordInALanguage'] = $currentWord;
		
    } else {  
		//Spausdinu neteisingai pasirinktus zodzius
		$_SESSION['currentIndex'] = 0;
		$currentWord = "No more words";
		$busenos = $_SESSION['busenos'];
		$i = 0;
		foreach ($_SESSION['busenos'] as $busena) {
			if ($busena == "neatsakyta"){
				$i++;
			}
		}
		
		
		if ($i>0) {
        	echo '<a style="font-size: 40px;">Neteisingai užrašyti žodžiai:</a><br><br><br>';
        	foreach ($_SESSION['incorrectWords'] as $incorrectWord) {
				$currentIndex = $_SESSION['currentIndex'] ?? 0;
				$busena = $busenos[$currentIndex];
				if ($busena == "neatsakyta"){
					echo '<a class="wrongWords">' . $incorrectWord . '</a>';
				}
				$_SESSION['currentIndex'] = $currentIndex + 1;
        	}
			
			
			// Create a form to submit the incorrect words
        	echo '<form action="issaugotiNeteisingus.php" method="post">';
        	foreach ($_SESSION['incorrectWords'] as $incorrectWord) {
            	 echo '<input type="hidden" name="incorrectWords[]" value="' . $incorrectWord . '">';
        	}
			foreach ($_SESSION['busenos'] as $busena) {     	
				echo '<input type="hidden" name="busenos[]" value="' . $busena . '">';
        	}
			
			echo '<br><br><br><br><br><a style="font-size: 30px;"><b>Norėdami išsaugoti progresą ir tęsti mokymąsi, spauskite: <b></a>';
			echo '<input type="submit" name="save" value="Tęsti" style="font-size: 25px" class="custom-button">';
        	echo '</form>';
				
			
    	} else {
			$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
			mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
			
			foreach ($_SESSION['incorrectWords'] as $word) {
				$updateQuery = "UPDATE ". TBL_WRONG_WORDS2 ." SET busena = 'atsakyta' WHERE user_id='$userid' 
					AND zodis='$word'";
            	mysqli_query($db, $updateQuery);
			}
			echo '<a style="font-size: 40px;">Visi žodžiai buvo užrašyti teisingai.</a><br><br><br><br><br><br>';
			echo '<a style="font-size: 30px;"><b> Norėdami grįžti atgal į menių, spauskite:<b> </a>'.'<a class="inline-link-1" href="index.php">Grįžti</a>';

    	}

    }
} 


?>

<html>
	
	<head>
		
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <style>
  			<?php include "include/styles.css" ?>
		</style>
    </head>
	
<body>

	
	 <form action="check_word.php" method="post">		 
	<?php if ($currentWord !== "No more words"): ?>
    	<div style="font-size: 25px" id="wordContainer">
			<h1 style="text-align: center;" >Išverskite žodį:</h1>
			<?php echo '<a class="wordStyle">' . $currentWord . '</a>'; ?><br><br><br>
			<input style="font-size: 20px " type="text" name="zodis"> <input type="submit" name="next" value="Toliau" class="custom-button">  

    	</div>
     	
		<input type="hidden" name="currentWord" value="<?php echo $currentWord; ?>">
     <?php endif;?>	 
	</form>
</body>
</html>