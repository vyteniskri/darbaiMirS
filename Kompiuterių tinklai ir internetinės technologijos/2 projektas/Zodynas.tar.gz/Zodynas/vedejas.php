<?php
include("index.php");
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[VEDEJAS_LEVEL]))   { header("Location: logout.php");exit;}

?>

<html>
	 <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Vedėjo sąsaja</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
	
	
	<body>
		<div class="italic-text" style="text-align: center; font-size: 20px ">
            <h1>Papildomų žodžių pagal kalbą, lygį ir tematiką pridėjimas </h1>
        </div>
		 <br>
		<?php echo $_SESSION['zodis_succses']; $_SESSION['zodis_succses']=""; ?>
	
		<form action="procvedejas.php" method="post">
			
			<p style="text-align:center; font-size:20px">Kalba:
    		<input class="custom-dropdown-smaller" type="text" name="kalba"><br>
			<?php echo $_SESSION['kalba_error']; $_SESSION['kalba_error']="";?>
			</p>
			
			<p style="text-align:center; font-size:20px">Lygis:
    		<input class="custom-dropdown-smaller" type="text" name="lygis"><br>
			<?php echo $_SESSION['lygis_error']; $_SESSION['lygis_error']="";?>
			</p>
			
			<p style="margin-left: -22px; font-size:20px">Tematika:
    		<input class="custom-dropdown-smaller" type="text" name="tematika"><br>
			<?php echo $_SESSION['tematika_error']; $_SESSION['tematika_error']="";?>
			</p>
			
			<p style="text-align:center; font-size:20px">Žodis:
    		<input class="custom-dropdown-smaller" type="text" name="zodis"><br>
			<?php echo $_SESSION['zodis_error'];
			 echo $_SESSION['zodisExsist_error']; $_SESSION['zodisExsist_error']=""; $_SESSION['zodis_error']="";?>
			</p>
			
			<p style="margin-left: -22px; font-size:20px">Vertimas:
    		<input class="custom-dropdown-smaller" type="text" name="vertimas"><br>
			<?php echo $_SESSION['vertimas_error']; $_SESSION['vertimas_error']="";?>
			</p>
			
    		<input type="submit" value="Pridėti" name="Pridėti" class="inline-link-1">
			
		</form>	
		<br>
		

	<form action="naikintiIrasa.php" method="post">
	<?php
    
	$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
	mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
	$sql = "SELECT * FROM " . TBL_WORDS2 . " ORDER BY kalba ASC, lygis ASC, tematika ASC, zodis ASC";
	$result = mysqli_query($db, $sql);
	if (!$result || (mysqli_num_rows($result) < 1))  
			{exit;}
	?>
		<div  style="float: right; font-size:20px">
			<b>Naikinti pasirinktus įrašus --------></b> <input type="submit" value="Vykdyti" name="Vykdyti" class="inline-link-1">
		</div>
    		<table class="center"  border="1" cellspacing="0" cellpadding="3">
    			<tr style="background-color: #FEC301;" ><td><b>Kalba</b></td><td><b>Lygis</b></td><td><b>Tematika</b></td><td><b>Žodis</b></td><td><b>Vertimas</b></td><td><b>Šalinti?</b></td></tr>
				<?php
				 	while($row = mysqli_fetch_assoc($result)) { 
						echo "<tr><td>".$row['kalba']."</td>";
						echo "<td>".$row['lygis']."</td>";
						echo "<td>".$row['tematika']."</td>";
						echo "<td>".$row['zodis']."</td>";
						echo "<td>".$row['vertimas']."</td>";
						echo "<td><input type=\"checkbox\" name=\"naikinti_".$row['zodis']."\"></td></tr>";
					}
				?>
			</table>
		
	
	</form>	
	
	</body>
</html>