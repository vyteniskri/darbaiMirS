<?php
session_start();

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

$incorectWordsArray = $_SESSION['incorrectWords'];
$corectWordsArray = $_SESSION['corectWords'];

if (!empty($incorectWordsArray)){
	$currentIndex = $_SESSION['currentIndex'] ?? 0;
	
	if ($currentIndex < count($incorectWordsArray)) {
		$currentWord = $incorectWordsArray[$currentIndex];
		$corectWord = $corectWordsArray[$currentIndex];
		$_SESSION['wordInALanguage'] = $currentWord;
		$_SESSION['currentCorrectWord'] = $corectWord;
		$_SESSION['currentIndex'] = $currentIndex + 1;
		
		
	} else {
		$_SESSION['currentIndex'] = 0;
		$currentWord = "No more words";
		
		if (!empty($_SESSION['incorrectWords2'])) {
        	echo "neteisingai užrašyti žodžiai:<br>";
        	foreach ($_SESSION['incorrectWords2'] as $incorrectWord) {
            	echo $incorrectWord . "<br>";
        	}
			
			 // Create a form to submit the incorrect words
        	echo '<form action="issaugotiNeteisingus.php" method="post">';
        	foreach ($_SESSION['incorrectWords2'] as $incorrectWord) {
            	echo '<input type="hidden" name="incorrectWords[]" value="' . $incorrectWord . '">';
        	}
        	echo '<input type="submit" name="save" value="Grįžti į pradžią">';
        	echo '</form>';
			
    	} else {
        	echo "Visi žodžiai buvo užrašyti teisingai" . "<br>";
			echo "Atgal į menių: ".'<a href="../index.php">Atgal</a>';
    	}


	}
}

?>

<html>
	
	<head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <style>
  			<?php include "../include/styles.css" ?>
		</style>
    </head>
	
<body>

	
	 <form action="check_word.php" method="post">		 
	<?php if ($currentWord !== "No more words"): ?>
		<table style="border-width: 2px; border-style: dotted;"><tr><td>
		Atgal į [<a href="../index.php">Pradžia</a>]
		</td></tr></table><br>	 
    	<div id="wordContainer">
			<h1 style="text-align: center;" >Išverskite žodį:</h1><br> 
			<?php echo $currentWord .":"; ?> <input type="text" name="zodis"><br>

    	</div>
     	<input type="submit" name="next" value="Toliau">  
		<input type="hidden" name="currentWord" value="<?php echo $currentWord; ?>">
     <?php endif; ?>	 
	</form>
	
</body>
</html>