<?php

session_start();

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Anglų kalba</title>
         <style>
  			<?php include "include/styles.css" ?>
		</style>
    </head>
    <body>
		
		<table style="border-width: 2px; border-style: dotted;"><tr><td>
         Atgal į [<a href="index.php">Pradžia</a>]
      	</td></tr></table><br>
		
        <table class="center" ><tr><td>  
		<div style="text-align: center;color:black">
            <h1>Anglų kalba</h1>
		</td></tr>
        </div>
	    </table>
		<h3>Pasirinkite mokymosi lygmenį:</h3>
		<tr><td>
			[<a href=\"operacija2.php\">Lygmuo 1</a>] &nbsp;&nbsp;
			[<a href=\"operacija2.php\">Lygmuo 2</a>] &nbsp;&nbsp;
			[<a href=\"operacija2.php\">Lygmuo 3</a>] &nbsp;&nbsp;
			[<a href=\"operacija2.php\">Lygmuo 4</a>] &nbsp;&nbsp;
		</td></tr>
	
	</body>
</html>
			