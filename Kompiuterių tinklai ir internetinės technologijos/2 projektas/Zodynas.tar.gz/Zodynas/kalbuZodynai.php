<?php
include("index.php");
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}


		//Pakeisti i nulines reiksmes
		$_SESSION['kalba'] = "";
		$_SESSION['lygis'] = "";
		$_SESSION['tematika'] = "";

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
      
         <style>
  			<?php include "include/styles.css" ?>
		</style>
    </head>
    <body>
		
		
		<div class="italic-text" style="text-align: center; font-size: 30px ">
            <h1>Mokomieji žodynai</h1>
        </div>
	   <br> <br> <br> <br> <br> <br>
		<div style="font-size: 25px ">
			<h3>Pasirinkite kalbą:</h3>
		</div>
	
	<form action="adresavimas.php" method="post">
    <select class="custom-dropdown" name="kalba" id="kalba">
        <?php
		$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
			 
        $query = "SELECT kalba FROM ". TBL_WORDS2 . " ORDER BY kalba ASC";
        $result = mysqli_query($db, $query);
		
		if ($result) {
			
			$repeatingLanguages = [];
  			while ($row = mysqli_fetch_assoc($result)) {
				
				if (!in_array($row['kalba'], $repeatingLanguages)) {
					$repeatingLanguages[] = $row['kalba'];
					echo '<option value="' . $row['kalba'] . '">' . $row['kalba'] . '</option>';
					
				}
        	}
	
		} else {
    		echo "Error in query: " . mysqli_error($db);
		}
		
        ?>
    </select>
    <input type="submit" name="next" value="Pasirinkti" class="custom-button">
	</form>
	
	</body>
	
</html>