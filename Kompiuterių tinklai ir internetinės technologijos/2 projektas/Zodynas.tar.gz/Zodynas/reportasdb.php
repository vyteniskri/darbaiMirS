<?php
session_start();

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

include("include/nustatymai.php");

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti
$userid = $_SESSION['userid'];


$sql = "SELECT w2.username, w2.email
	FROM " . TBL_WRONG_WORDS2 . " AS w1
	INNER JOIN " . TBL_USERS . " AS w2 ON w1.user_id = w2.userid
	WHERE w1.user_id = '$userid'";

	$resultsNaudotojoInfo= mysqli_query($db, $sql);
	$userInfo = mysqli_fetch_assoc($resultsNaudotojoInfo);


$sql = "SELECT w1.zodis, w1.kiekis, w2.kalba, w2.tematika, w2.lygis, w2.vertimas 
	FROM " . TBL_WRONG_WORDS2 . " AS w1
	INNER JOIN " . TBL_WORDS2 . " AS w2 ON w1.zodis = w2.zodis
	WHERE w1.user_id = '$userid'
	ORDER BY w1.kiekis DESC";

	$resultsZodziuInfo= mysqli_query($db, $sql);

$wordsInfo = [];
while ($row = mysqli_fetch_assoc($resultsZodziuInfo)) {
    $wordsInfo[] = $row;
}

$combinedResults = [
    'userInfo' => $userInfo,
    'wordsInfo' => $wordsInfo,
];

$_SESSION['combinedResults'] = $combinedResults;
$_SESSION['noReport'] = "<font size=\"6\" color=\"#ff0000\">* Jūsų žodžių reportas yra tuščias</font>";
header("Location:reportas.php");
?>