<?php
include("index.php");
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

$_SESSION['tematika'] = "";

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti

$kalba = $_SESSION['kalba']; //Kalba
$lygis = $_SESSION['lygis']; //Lygis


?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
      
         <style>
  			<?php include "include/styles.css" ?>
		</style>
    </head>
    <body>
		
		 <table style="border-width: 2px; text-align: center;  font-size: 20px"><tr><td>
		 Norėdami pakeisti <a style="font-style: italic; font-weight: bold;">lygį</a> spauskite: <a class='inline-link-1' href="kalbosPuslapis.php">Keisti</a><br>
      	</td></tr></table>
         
		<div class="italic-text" style="text-align: center; font-size: 25px ">
            <h1><?php echo $kalba?> kalba, <?php echo $lygis?> lygis</h1>
		</td></tr>
        </div>

	
 	<br> <br> <br> <br> <br> <br>
	<div style="font-size: 25px ">
		<h3>Pasirinkite tematiką:</h3>
	</div>
	<form action="adresavimas.php" method="post">
    <select class="custom-dropdown" name="tematika" id="tematika">
        <?php
        
		$query = "SELECT tematika FROM ". TBL_WORDS2 . " WHERE kalba='$kalba' AND lygis='$lygis' ORDER BY tematika ASC ";
        $result = mysqli_query($db, $query);
		if ($result) {
			
			$repeatingTematikos = [];
  			while ($row = mysqli_fetch_assoc($result)) {
				if (!in_array($row['tematika'], $repeatingTematikos)) {
					$repeatingTematikos[] = $row['tematika'];
					echo '<option value="' . $row['tematika'] . '">' . $row['tematika'] . '</option>';
				}
        	}
	
		} else {
    		echo "Error in query: " . mysqli_error($db);
		}	 
        ?>
    </select>
	<input type="submit" name="next" value="Pasirinkti" class="custom-button">
	</form>
	
	
	
	
		
		
	
	</body>
</html>
			