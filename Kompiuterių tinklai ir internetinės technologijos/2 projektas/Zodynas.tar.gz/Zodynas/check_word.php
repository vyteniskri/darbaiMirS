<?php
session_start();

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}
include("include/nustatymai.php");


$currentWord = $_POST['zodis'] ?? ''; //Ivestas zodis
$wordInALanguage = $_SESSION['wordInALanguage'];//Zodis uzsienio kalba

$currentCorrectWord = $_SESSION['currentCorrectWord'] ?? ''; //Tinkamas zodis lietuviu kalba
if ($currentWord != $currentCorrectWord) {
    $_SESSION['incorrectWords'][] = $wordInALanguage;//iskelti i virsu
	$_SESSION['corectWords'][] = $currentCorrectWord;//nereikia
	$_SESSION['busenos'][] = "neatsakyta";
} else {
	$_SESSION['incorrectWords'][] = $wordInALanguage;//iskelti i virsu
	$_SESSION['busenos'][] = "atsakyta";
}

header("Location:mokymosi_puslapis.php");

?>