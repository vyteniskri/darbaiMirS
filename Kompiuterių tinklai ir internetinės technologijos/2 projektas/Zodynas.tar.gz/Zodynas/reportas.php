<?php
include("index.php");

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti


$combinedResults = $_SESSION['combinedResults'];

?>

<html>
	 <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Reportas</title>
         <style>
  			<?php include "include/styles.css" ?>
		</style>
    </head>
	
	
	<body>
		<div class="italic-text" style="text-align: center; font-size: 20px ">
            <h1>Mano sunkiausiai įsimenamų žodžių reportas </h1>
        </div>
		
		<form action="reportasdb.php" method="post">
			<input type="submit" value="Spausdinti" name="spausdinti" class="inline-link-1">
		</form>
		<?php if (!empty($combinedResults['userInfo'])) { ?>
		<table class="center"  border="1" cellspacing="0" cellpadding="3">
			
			<tr style="background-color: #FEC301;" ><td></td><td></td><td><b>Slapyvardis</b></td><td><b>el.Paštas</b></td><td></td><td></td></tr>
			
				<?php
					$userInfo = $combinedResults['userInfo'];
					echo "<tr><td></td><td></td><td>".$userInfo['username']."</td>";
					echo "<td>".$userInfo['email']."</td><td></td><td></td></tr>";

					$wordsInfo = $combinedResults['wordsInfo'];
					echo "<tr style='background-color: #FEC301;'  ><td><b>Žodis</b></td><td><b>Kalba</b></td><td><b>Tematika</b></td><td><b>Lygis</b></td><td><b>Vertimas</b></td><td><b>Kiekis</b></td></tr>";
    				foreach ($wordsInfo as $word) {
        				echo "<tr><td>" . $word['zodis'] . "</td>";
        				echo "<td>" . $word['kalba'] . "</td>";
        				echo "<td>" . $word['tematika'] . "</td>";
        				echo "<td>" . $word['lygis'] . "</td>";
        				echo "<td>" . $word['vertimas'] . "</td>";
        				echo "<td>" . $word['kiekis'] . "</td></tr>";
    				}
			} else {
				echo $_SESSION['noReport'];
				$_SESSION['noReport']="";
			}
				?>
		</table>
	</body>
	
</html>