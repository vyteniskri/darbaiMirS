<?php
session_start();
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index")) {
    header("Location: logout.php");
    exit;
}
		$_SESSION['currentIndex'] = 0; //Iteravimui per zodzius
		//Pirmas mokymosi puslapis
		$_SESSION['incorrectWords'] = [];//Neteisingu zodziu masyvas
		$_SESSION['wordsArray1'][] = [];
		$_SESSION['correctWordsArray1'][] = [];
		$_SESSION['busenos'] = [];
		//Antras mokymosi puslapis
		//$_SESSION['incorrectWords2'] = [];//2 lygmens neteisingu zodziu masyvas
		//$_SESSION['corectWords'] = []; //Teisingu zodziu masyvas, sudarytas po pirmojo etapo
		

include("include/nustatymai.php");
include("shuffleWords.php");

$kalba = $_SESSION['kalba'];
$level = $_SESSION['lygis'];
$tematika = $_SESSION['tematika'];
$userid = $_SESSION['userid'];

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
mysqli_set_charset($db, "utf8mb4"); //Lietuviskiem simboliams naudoti

$result = "SELECT COUNT(w1.zodis) AS num_findings
FROM ". TBL_WRONG_WORDS2 ." AS w1
WHERE w1.user_id = '$userid' 
  AND w1.busena = 'neatsakyta'
  AND EXISTS (
    SELECT 1
    FROM ". TBL_WORDS2 ." AS w2
    WHERE w2.zodis = w1.zodis
      AND w2.kalba = '$kalba'
      AND w2.lygis = '$level'
      AND w2.tematika = '$tematika'
      AND EXISTS (
        SELECT 1
        FROM ". TBL_WRONG_WORDS2 ."
        WHERE user_id='$userid' 
		  AND zodis = w2.zodis
          AND busena = 'neatsakyta'
      )
  );"; //Randa zodzius neastasakytu zodziu duomenu bazeje
	
    $result = mysqli_query($db, $result); 
	
	if ($result) {
        $row = mysqli_fetch_array($result);
        $count = $row['num_findings'];

		if ($count == 0) { //Imami zodzius is zodziu duombazes, jei nera neatsakytu zodziu
			
			$sql = "SELECT zodis, vertimas FROM ". TBL_WORDS2 ." 
				WHERE  kalba='$kalba'
 				AND lygis='$level'
				AND tematika='$tematika'"; //Randami zodziai pagal kalba, lygi ir tematika

			$result = mysqli_query($db, $sql);
			if ($result) {
				$wordsArray = [];
    			while ($row = mysqli_fetch_assoc($result)) {
         			$wordsArray[] = $row['zodis'];
		 			$correctWordsArray[] = $row['vertimas'];
    			}
	
				list($wordsArray, $correctWordsArray) = shuffle_arrays_simultaneously($wordsArray, $correctWordsArray);

				$_SESSION['wordsArray1'] = $wordsArray;
				$_SESSION['correctWordsArray1'] = $correctWordsArray;
	
			} else {
    			echo "Error in query: " . mysqli_error($db);
			}
				
		} else { //Jei yra neatsakytu zodziu imti juos is neatsakytu zodziu duomenu bazes
			$words = "SELECT w1.zodis, w2.vertimas
          		FROM " . TBL_WRONG_WORDS2 . " AS w1
          		INNER JOIN " . TBL_WORDS2 . " AS w2 ON w1.zodis = w2.zodis
          		WHERE w1.user_id = '$userid' 
            		AND w1.busena = 'neatsakyta'
            		AND w2.kalba = '$kalba'
            		AND w2.lygis = '$level'
            		AND w2.tematika = '$tematika'
            		AND EXISTS (
              			SELECT 1
        				FROM " . TBL_WRONG_WORDS2 . "
              			WHERE user_id='$userid' 
                			AND zodis = w2.zodis
                			AND busena = 'neatsakyta'
            		);";
            $result = mysqli_query($db, $words);
			
			if ($result) {
				$wordsArray = [];
    			while ($row = mysqli_fetch_assoc($result)) {
         			$wordsArray[] = $row['zodis'];
		 			$correctWordsArray[] = $row['vertimas'];
    			}
	
				list($wordsArray, $correctWordsArray) = shuffle_arrays_simultaneously($wordsArray, $correctWordsArray);

				$_SESSION['wordsArray1'] = $wordsArray;
				$_SESSION['correctWordsArray1'] = $correctWordsArray;
	
			} else {
    			echo "Error in query: " . mysqli_error($db);
			}
		}
		
	} else {
		echo "Error in check query: " . mysqli_error($db);
	}

header("Location:mokymosi_puslapis.php");
?>