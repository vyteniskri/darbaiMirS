<?php

session_start(); 

if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
	{ header("Location: logout.php");exit;}

include("include/nustatymai.php");
include("include/functions.php");

$kalba = isset($_POST['kalba']) ? $_POST['kalba'] : '';
$lygis = isset($_POST['lygis']) ? $_POST['lygis'] : '';
$tematika = isset($_POST['tematika']) ? $_POST['tematika'] : '';
$zodis = isset($_POST['zodis']) ? $_POST['zodis'] : '';
$vertimas = isset($_POST['vertimas']) ? $_POST['vertimas'] : '';

$_SESSION['kalba_error']="";
$_SESSION['lygis_error']="";
$_SESSION['tematika_error']="";
$_SESSION['zodis_error']="";
$_SESSION['vertimas_error']="";
$_SESSION['zodisExsist_error']="";
$_SESSION['zodis_succses']="";

$userid = $_SESSION['userid'];

$index = 0;

if ($kalba == ''){
	$_SESSION['kalba_error'] =  "<font size=\"3\" color=\"#ff0000\">* Neįvesta kalba</font>";
	$index=$index+1;
}
if ($lygis == ''){
	$_SESSION['lygis_error'] =  "<font size=\"3\" color=\"#ff0000\">* Neįvestas lygis</font>";
	$index=$index+1;
}
if(!preg_match("/^([0-9])*$/", $lygis)){
	$_SESSION['lygis_error'] =  "<font size=\"3\" color=\"#ff0000\">* Turite įvesti skaičių</font>";
	$index=$index+1;
}
if ($tematika == ''){
	$_SESSION['tematika_error'] =  "<font size=\"3\" color=\"#ff0000\">* Neįvesta tematika</font>";
	$index=$index+1;
}
if ($zodis == ''){
	$_SESSION['zodis_error'] =  "<font size=\"3\" color=\"#ff0000\">* Neįvestas žodis</font>";
	$index=$index+1;
}
if ($vertimas == ''){
	$_SESSION['vertimas_error'] =  "<font size=\"3\" color=\"#ff0000\">* Neįvestas žodžio vertimas</font>";
	$index=$index+1;
}

if (checkUserWord($zodis, $userid)){
	$_SESSION['zodisExsist_error']="<font size=\"3\" color=\"#ff0000\">* Toks žodis jau egzistuoja </font>";
} else {
	if ($index == 0){
		addUserWord($userid, $kalba, $lygis, $tematika, $zodis, $vertimas);
		$_SESSION['zodis_succses'] =  "<font size=\"6\" color=\"#00ff00\">* Žodis sėkmingai išsaugotas</font>";
	}
}

header("Location:manozodynas.php");exit;
?>


