<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pasirinktaKalba = $_POST['kalba'];
    $_SESSION['kalba'] = $pasirinktaKalba;
	header("Location:../zodynai/{$pasirinktaKalba}.php");
    exit();
}
?>