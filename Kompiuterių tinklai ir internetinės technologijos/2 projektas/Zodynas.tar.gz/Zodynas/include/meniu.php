<?php
// meniu.php  rodomas meniu pagal vartotojo rolę

if (!isset($_SESSION)) { header("Location: logout.php");exit;}
include("include/nustatymai.php");
$userlevel=$_SESSION['ulevel'];

		
     	echo "<table width=100% border=\"0\" cellspacing=\"1\" cellpadding=\"3\" class=\"meniu\">";
        echo "<tr><td>";

       	echo "<span style='float: left;'><a class='inline-link-1'; href='index.php'>Pradžia</a></span>";

		if ($userlevel == $user_roles[DEFAULT_LEVEL] ) {
			echo "<a class='inline-link-1'; href=\"kalbuZodynai.php\">Mokomieji žodynai</a> &nbsp;&nbsp;";
			echo "<a class='inline-link-1'; href=\"manozodynas.php\">Mano žodynas</a> &nbsp;&nbsp;";
			echo "<a class='inline-link-1'; href=\"reportas.php\">Mano reportas</a> &nbsp;&nbsp;";
		}
        echo "<a class='inline-link-1'; href=\"useredit.php\">Redaguoti paskyrą</a> &nbsp;&nbsp;";
        //Administratoriaus sąsaja rodoma tik administratoriui
        if ($userlevel == $user_roles[ADMIN_LEVEL] ) {
            echo "<a class='inline-link-1'; href=\"admin.php\">Administratoriaus sąsaja</a> &nbsp;&nbsp;";
        }
		if ($userlevel == $user_roles[VEDEJAS_LEVEL]){ //Vedejas
			echo "<a class='inline-link-1'; href=\"vedejas.php\">Vedėjo sąsaja</a> &nbsp;&nbsp;";
		}
        echo "<a class='logout-link'; href=\"logout.php\">Atsijungti</a></div>";
		echo "</td></tr></table>";
		

?>       
<html>
	<body>
		<br><br><br>
		<?php if (basename($_SERVER['PHP_SELF']) == 'index.php') { ?>
		<div class="header">
                    
                    <h1>Užsienio kalbų žodžių mokymosi aplinka</h1>
					<h2>Autorius: Vytenis Kriščiūnas</h2>
					<br>
                </div>
			<img class="oval-image"; src="knygosNuotrauka.jpg" alt="Nuotrauka">
		<?php } ?>
	</body>
</html>