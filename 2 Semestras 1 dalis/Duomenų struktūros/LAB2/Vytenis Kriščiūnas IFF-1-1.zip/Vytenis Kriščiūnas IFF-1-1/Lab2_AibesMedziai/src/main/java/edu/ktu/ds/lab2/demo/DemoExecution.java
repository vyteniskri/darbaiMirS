package edu.ktu.ds.lab2.demo;

import edu.ktu.ds.lab2.gui.MainWindow;

/*
 * Darbo atlikimo tvarka - čia yra pradinė Swing GUI klasė.
 */
public class DemoExecution {

    public static void main(String[] args) {
        MainWindow.createAndShowGUI();
    }
}
